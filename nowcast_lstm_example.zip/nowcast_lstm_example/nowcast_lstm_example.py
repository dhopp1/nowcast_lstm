#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import matplotlib.pyplot as plt
import dill # for loading and saving a trained model
from nowcast_lstm.LSTM import LSTM


# In[2]:


data = pd.read_csv("data.csv") # reading in data
data = data.loc[:, ["x_jp", "x_world", "x_de", "x_uk", "ipi_cn"]] # random subset of columns


# In[3]:


training = data.loc[:len(data)*0.8,:] # training and test datasets
test = data.loc[len(data)*0.8:,:]


# In[4]:


model = LSTM(data=training, target_variable="x_world", n_timesteps=12, n_models=10, train_episodes=50) # instantiating model


# In[5]:


model.train(quiet=True) # training model, suppress printing of training loss


# In[6]:


# performance on the train set
plt.plot(model.y, label="actual") 
plt.plot(model.predict(model.X), label="predictions")
plt.legend();


# In[7]:


new_data = LSTM(data=test, target_variable="x_world", n_timesteps=12) # creating a new LSTM object from the test set, primarily to transform data


# In[8]:


# performance on the test set
plt.plot(new_data.y, label="actual")
plt.plot(model.predict(new_data.X), label="predictions")
plt.legend();


# In[9]:


# saving a trained model
dill.dump(model, open("trained_model.pkl", mode='wb'))


# In[10]:


# load a trained model
trained_model = dill.load(open("trained_model.pkl", "rb", -1))

